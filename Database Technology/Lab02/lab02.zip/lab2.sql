/*
Lab 2 report <Thijs Quast (thiqu264), Lennart Schilling (lensc874) > 
*/

/*
Drop all user created tables that have been created when solving the lab
*/

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS Own_table CASCADE;
DROP VIEW IF EXISTS debit_costs1 CASCADE;
DROP VIEW IF EXISTS debit_costs2 CASCADE;
DROP VIEW IF EXISTS cheap_items CASCADE;
DROP TABLE IF EXISTS jbcity CASCADE;
DROP TABLE IF EXISTS jbdebit CASCADE;
DROP TABLE IF EXISTS jbdept CASCADE;
DROP TABLE IF EXISTS jbemployee CASCADE;
DROP TABLE IF EXISTS jbitem CASCADE;
DROP TABLE IF EXISTS jbparts CASCADE;
DROP TABLE IF EXISTS jbsale CASCADE;
DROP VIEW IF EXISTS jbsale_supply CASCADE;
DROP TABLE IF EXISTS jbstore CASCADE;
DROP TABLE IF EXISTS jbsupplier CASCADE;
DROP TABLE IF EXISTS jbsupply CASCADE;


DROP TABLE IF EXISTS jbmanager CASCADE;
DROP TABLE IF EXISTS jbmanager CASCADE;
DROP TABLE IF EXISTS jbmanager CASCADE;
DROP TABLE IF EXISTS jbmanager CASCADE;
DROP TABLE IF EXISTS jbmanager CASCADE;
DROP TABLE IF EXISTS jbmanager CASCADE;
DROP TABLE IF EXISTS jbmanager CASCADE;

SET FOREIGN_KEY_CHECKS = 1;

/* Have the source scripts in the file so it is easy to recreate!*/

SOURCE company_schema.sql;
SOURCE company_data.sql;

/*
#################################### Question 3 ####################################

First, we create the table jbmanager.
The bonus attribute is initialized by default to 0 as a float. Ideally, you would also have to specify a constraint
that a every value that is added is also equal or greater than zero.
*/

CREATE TABLE IF NOT EXISTS jbmanager(
    manager_id int,
    bonus float DEFAULT 0,
    constraint pk_manager
        primary key (manager_id),
    constraint fk_manager_to_employee
        FOREIGN KEY (manager_id) references jbemployee(id)
);

/* Afterwards, we fill it with existing manager data. */

INSERT INTO jbmanager (manager_id) 
    (SELECT DISTINCT manager FROM jbemployee
    WHERE manager is not NULL)
    UNION
    (SELECT DISTINCT manager FROM jbdept
    WHERE manager is not NULL);

/*
+------------+-------+
| manager_id | bonus |
+------------+-------+
|         10 |     0 |
|         13 |     0 |
|         26 |     0 |
|         32 |     0 |
|         33 |     0 |
|         35 |     0 |
|         37 |     0 |
|         55 |     0 |
|         98 |     0 |
|        129 |     0 |
|        157 |     0 |
|        199 |     0 |
+------------+-------+
12 rows in set (0.00 sec)

Furthermore, we need to add the foreign key constraints in jbemployee and jbdept. */

ALTER TABLE jbemployee  
ADD CONSTRAINT fk_employee_to_manager 
    FOREIGN KEY (manager) REFERENCES jbmanager(manager_id) ON DELETE CASCADE;  

ALTER TABLE jbdept  
ADD CONSTRAINT fk_dept_to_manager 
    FOREIGN KEY (manager) REFERENCES jbmanager(manager_id) ON DELETE CASCADE; #

/*

The following command shows that the constraint have been implemented. The second line of the output shows the 
implemented constraint.

mysql> SELECT * FROM information_schema.TABLE_CONSTRAINTS;
+--------------------+-------------------+------------------------+--------------+------------+-----------------+
| CONSTRAINT_CATALOG | CONSTRAINT_SCHEMA | CONSTRAINT_NAME        | TABLE_SCHEMA | TABLE_NAME | CONSTRAINT_TYPE |
+--------------------+-------------------+------------------------+--------------+------------+-----------------+
| def                | lensc874          | PRIMARY                | lensc874     | jbmanager  | PRIMARY KEY     |
| def                | lensc874          | fk_manager_to_employee | lensc874     | jbmanager  | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbsale     | PRIMARY KEY     |
| def                | lensc874          | fk_sale_debit          | lensc874     | jbsale     | FOREIGN KEY     |
| def                | lensc874          | fk_sale_item           | lensc874     | jbsale     | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbdebit    | PRIMARY KEY     |
| def                | lensc874          | fk_debit_employee      | lensc874     | jbdebit    | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbsupplier | PRIMARY KEY     |
| def                | lensc874          | fk_supplier_city       | lensc874     | jbsupplier | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbsupply   | PRIMARY KEY     |
| def                | lensc874          | fk_supply_parts        | lensc874     | jbsupply   | FOREIGN KEY     |
| def                | lensc874          | fk_supply_supplier     | lensc874     | jbsupply   | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbstore    | PRIMARY KEY     |
| def                | lensc874          | fk_store_city          | lensc874     | jbstore    | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbitem     | PRIMARY KEY     |
| def                | lensc874          | fk_item_dept           | lensc874     | jbitem     | FOREIGN KEY     |
| def                | lensc874          | fk_item_supplier       | lensc874     | jbitem     | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbparts    | PRIMARY KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbdept     | PRIMARY KEY     |
| def                | lensc874          | fk_dept_mgr            | lensc874     | jbdept     | FOREIGN KEY     |
| def                | lensc874          | fk_dept_store          | lensc874     | jbdept     | FOREIGN KEY     |
| def                | lensc874          | fk_dept_to_manager     | lensc874     | jbdept     | FOREIGN KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbcity     | PRIMARY KEY     |
| def                | lensc874          | PRIMARY                | lensc874     | jbemployee | PRIMARY KEY     |
| def                | lensc874          | fk_emp_mgr             | lensc874     | jbemployee | FOREIGN KEY     |
| def                | lensc874          | fk_employee_to_manager | lensc874     | jbemployee | FOREIGN KEY     |
+--------------------+-------------------+------------------------+--------------+------------+-----------------+
26 rows in set (0.29 sec)


#################################### Question 4 ####################################
*/

UPDATE jbmanager SET bonus = 10000 WHERE manager_id in 
(SELECT DISTINCT manager FROM jbdept);

/*

SELECT * FROM jbmanager;
+------------+-------+
| manager_id | bonus |
+------------+-------+
|         10 | 10000 |
|         13 | 10000 |
|         26 | 10000 |
|         32 | 10000 |
|         33 | 10000 |
|         35 | 10000 |
|         37 | 10000 |
|         55 | 10000 |
|         98 | 10000 |
|        129 | 10000 |
|        157 | 10000 |
|        199 |     0 |
+------------+-------+
12 rows in set (0.00 sec)
*/

/*
#################################### Question 5 ####################################

The derived EER-diagram (attached to the repository as "eer_q5.jpg") will be implemented.

First, we create a table for the entity type "Customer". 
"cust_id" is chosen as the primary key, "city_id" is a foreign key referring to jbcity.id . */

CREATE TABLE IF NOT EXISTS jbcustomer(
    cust_id int,
    first_name varchar(30),
    last_name varchar(30),
    street_address varchar(30),
    city_id int,
    constraint pk_customer
        primary key (cust_id),
    constraint fk_customer_to_city
        FOREIGN KEY (city_id) references jbcity(id)
);

/* Then, we can create a table for the entity type "Account". 
"account_no" is chosen as the primary key, "cust_id" is a foreign key referring to jbcustomer.cust_id . */

CREATE TABLE IF NOT EXISTS jbaccount(
    account_no int,
    balance float,
    cust_id int,
    constraint pk_customer
        primary key (account_no),
    constraint fk_account_to_customer
        FOREIGN KEY (cust_id) references jbcustomer(cust_id)
);

/* Then, we can create a table for the entity type "Transaction". 
"trans_no" is chosen as the primary key, "employee_resp" is a foreign key referring to jbemployee.id.
"account_used" is a foreign key referring to jbaccount.account_no. */

CREATE TABLE IF NOT EXISTS jbtransaction(
    trans_no int,
    t_date date,
    t_time TIME,
    employee_resp int,
    account_used int,
    constraint pk_transaction
        primary key (trans_no),
    constraint fk_transaction_to_employee
        FOREIGN KEY (employee_resp) references jbemployee(id),
    constraint fk_transaction_to_account
        FOREIGN KEY (account_used) references jbaccount(account_no)
);

/* Then, we can create the subclasses withdrawal and deposit. */
CREATE TABLE IF NOT EXISTS jbwithdrawal(
    referred_trans int,
    amount float,
    constraint pk_customer
        primary key (referred_trans),
    constraint fk_withdrawal_to_transaction
        FOREIGN KEY (referred_trans) references jbtransaction(trans_no)
);

CREATE TABLE IF NOT EXISTS jbdeposit(
    referred_trans int,
    amount float,
    constraint pk_customer
        primary key (referred_trans),
    constraint fk_deposit_to_transaction
        FOREIGN KEY (referred_trans) references jbtransaction(trans_no)
);

/* Finally, we have to modify the debit table.
In the original EER-diagram, jbdebit contained the column "employee" as a 
foreign key referring to jbemployee. Since jbdebit is now a subclass of 
jbtransaction and the foreign key is implemented for jbtransaction, we
have to remove this foreign key constraint from jbdebit because it is already
implemented for the superclass. To do so, we first need to find out the name of this constraint.*/
SELECT * FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_NAME like "jbdebit";
/* It can be seen that the foreign key we want to remove is named as "fk_debit_employee". Consequently, we will remove this fk-constraint. */
alter table jbdebit drop foreign key fk_debit_employee;
/* The following output confirms that the fk-constraint has been dropped. */
SELECT * FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_NAME like "jbdebit";

/* We do not have to modify jbsale. It has a foreign key constraint referring to
jbdept, but that is fine. Therefore we are done with our implementation.*/
